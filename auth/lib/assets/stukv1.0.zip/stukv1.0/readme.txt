Para ejecutar el programa: 

- Instalar los requisitos
    
  $ pip install -r requirements.txt
 
- Ejecutar el programa principal

  $ python stuck.py OTP
  
- Recomendamos crear un alias para llamar al programa
  
  $ stuk() { python stuk.py "$@";}
  $ stuk 88299
